from flask import Flask, render_template, request
import sqlite3


app = Flask(__name__)

@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':

        conn = sqlite3.connect('user_data.db')
        cursor = conn.cursor()

    # return render_template('index.html')
#HTML Form
        name = request.form['name']
        password = request.form['password']

#Query
        query = "SELECT name,password FROM users where name= '"+name+"' and password= '"+password+"'"
        cursor.execute(query)

        results = cursor.fetchall()

#Validation
        if len(results) == 0:
            print("Sorry! Incorrect Credentials Provided. Try Again")
        else:
            return render_template('login.html')
    
    return render_template('index.html')







if __name__ == '__main__':
    app.run(debug=True)